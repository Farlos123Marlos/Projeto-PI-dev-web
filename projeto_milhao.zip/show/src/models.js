const { Sequelize } = require("sequelize");
const database = require('./db')

const Scoreboard = database.define('scoreboard', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    name: {
        type: Sequelize.STRING,
        allowNull: false
    },
    score:{
        type: Sequelize.INTEGER,
        allowNull: false
    }
})

module.exports = {Scoreboard}