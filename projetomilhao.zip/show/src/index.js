const sqlite3 = require('sqlite3').verbose();
const express = require('express');
const morgan = require('morgan')
const bodyParser = require('body-parser');

const db = require('./db')
const {Scoreboard} = require('./models')
const config = require('./config.json')
const questions = require('./questions.json')
const utils = require('./utils')
const _ = require('lodash')

const app = express()
app.use(morgan("tiny"))
app.use(bodyParser.json())

app.use(express.static("static"));

app.get("/scoreboard", async (req, res) => {
    const scoreboard = await Scoreboard.findAll({
        order: [['score', 'DESC']],
        limit: 10
    });

    res.json(scoreboard);
})

app.post("/cards", (req, res) => {
    const {id, card} = req.body;

    let q = _.cloneDeep(questions[id]);
    delete q.enunciado
    delete q.id
    delete q["alternativa"+q.alternativaCorreta]
    delete q.alternativaCorreta
    q = utils.shuffle(Object.keys(q));
    
    for (let i=3; i>card; i--){
        q.pop();
    }
    
    q = q.map(v => {
        return v[11]
    })
    q.filter(v => {
        return v ? true : false
    })

    res.json(q);
})

app.post("/placas", (req, res) => {
    const {id} = req.body;
    let alts = ["A", "B", "C", "D"]

    alts.splice(alts.indexOf(questions[id].alternativaCorreta), 1);
    alts = utils.shuffle(alts)

    let q = []
    q.push(questions[id].alternativaCorreta);
    q.push(alts[0]);
    q.push(alts[1]);

    let placas = [questions[id].alternativaCorreta]

    for (let i=0; i<3; i++){
        let j = Math.round(Math.random()*2)
        placas.push(q[j]);
    }

    placas = utils.shuffle(placas)
    res.json(placas)
})

app.post("/uni", (req, res) => {
    const {id} = req.body;
    let alts = ["A", "B", "C", "D"]
    const c = questions[id].alternativaCorreta

    alts.splice(alts.indexOf(c), 1);
    alts = utils.shuffle(alts)

    let q = []
    q.push(c);
    q.push(alts[0]);

    let uni = [c, c]

    for (let i=0; i<2; i++){
        let j = Math.round(Math.random()*1)
        uni.push(q[j]);
    }

    uni = utils.shuffle(uni);
    res.json(uni)
})

app.get("/questions", (req, res) => {
    let q = _.cloneDeep(questions)

    q.map((v) => {
        delete v.alternativaCorreta;
    })

    res.json(q);
})

app.post("/answer", (req, res) => {
    const {id, answer} =  req.body
    const q = questions[id]

    const correct = q.alternativaCorreta == answer ? true : false

    res.json(correct);
})


app.post("/save_score", async (req, res) => {
    let {name, score} = req.body;

    name = name ?? "User" + Math.round(Math.random() * 10000000);
    score = score ?? 0;

    try{
        Scoreboard.create({name: name, score: score})
    }
    catch (e){
        res.status(500).json({"ERROR": "something went wrong"})
        console.log(e)
        return;
    }

    res.json(true);
})


// sync database
async function syncDatabase(){
    const resultado = await db.sync();
}

app.listen(config.PORT, () => {
    syncDatabase();
    console.log(`App listening on port ${config.PORT}`)
})
