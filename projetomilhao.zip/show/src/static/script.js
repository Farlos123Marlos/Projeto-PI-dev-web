
// globals
let questions;
let p;
let money = 0;
let nextMoney = 500;


// https://stackoverflow.com/questions/2450954/how-to-randomize-shuffle-a-javascript-array
function shuffle(array) {
  let currentIndex = array.length,  randomIndex;

  // While there remain elements to shuffle...
  while (currentIndex != 0) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;

    // And swap it with the current element.
    [array[currentIndex], array[randomIndex]] = [
      array[randomIndex], array[currentIndex]];
  }

  return array;
}

function nextQuestion(){
  p = questions.pop();
  $("#pergunta").text(p.enunciado)
  $("#aA").text(p.alternativaA)
  $("#aB").text(p.alternativaB)
  $("#aC").text(p.alternativaC)
  $("#aD").text(p.alternativaD)

  $("#aA").css({opacity: 1})
  $("#aB").css({opacity: 1})
  $("#aC").css({opacity: 1})
  $("#aD").css({opacity: 1})
}

function gameOver(){
  alert(`Você errou! Dinheiro feito: ${money}`);
  const name = prompt("Digite seu nome: ");
  const data = JSON.stringify({name: name, score: money})
  fetch("/save_score", {method: "POST", body: data, headers: {"Content-Type": "application/json"}})
  location = "/"
}

function gameWon(){
  alert(`Você ganhou! Dinheiro feito: ${money}`);
  const name = prompt("Digite seu nome: ");
  const data = JSON.stringify({name: name, score: money})
  fetch("/save_score", {method: "POST", body: data, headers: {"Content-Type": "application/json"}})
  location = "/"
}

function gameStop(){
  alert(`Você escolheu parar! Dinheiro feito: ${money}`);
  const name = prompt("Digite seu nome: ");
  const data = JSON.stringify({name: name, score: money})
  fetch("/save_score", {method: "POST", body: data, headers: {"Content-Type": "application/json"}})
  location = "/"
}

async function answer(a){

  const data = JSON.stringify({id: p.id, answer: a})
  const correct = await (await fetch("/answer", {method: "POST", headers: {"Content-Type": "application/json"}, body: data})).text()

  if (correct == "true"){
    money = nextMoney
    if(money > 1000000){
        gameWon();
    }
    nextMoney *= 2
    setMoneyInfo();
    nextQuestion();
  }
  else{
    money /= 2;
    gameOver();
  }
}

function disableHelp(e){
  let el = $(e);
  
  if (el.data("enabled") !== true){
    return false;
  }

  el.data("enabled", false)
  el.css({opacity: 0.3})
  return true
}

function skip(e){
  
  if (disableHelp(e)){
    nextQuestion();
  }
  
}

async function uni(e){
  if(disableHelp(e)){
    const data = JSON.stringify({id: p.id})
    const ps = JSON.parse(await (await fetch("/uni", {method: "POST", headers: {"Content-Type": "application/json"}, body: data})).text())

    let msg = "Universitarios:\n";
    for (let v of ps){
      msg += v;
      msg += "\n";
    }

    alert(msg)
  }
}

async function placas(e){
  if(disableHelp(e)){
    const data = JSON.stringify({id: p.id})
    const ps = JSON.parse(await (await fetch("/placas", {method: "POST", headers: {"Content-Type": "application/json"}, body: data})).text())

    let msg = "Placas:\n";
    for (let v of ps){
      msg += v;
      msg += "\n";
    }

    alert(msg)
  }
}

async function cards(e){
  if(disableHelp(e)){
    const card = Math.round(Math.random() * 3)

    alert(`Voce tirou a carta ${card}`)
    const data = JSON.stringify({card: card, id: p.id})
    const qs = JSON.parse(await (await fetch("/cards", {method: "POST", headers: {"Content-Type": "application/json"}, body: data})).text())

    for(let q of qs){
      $("#a"+q).css({opacity: 0.3});
    }
  }
}

function setMoneyInfo(){
  $("#pararDinheiro").text(`Parar: R$ ${money}`);
  $("#errar").text(`Errar: R$ ${money / 2}`);
  $("#acertar").text(`Acertar: R$ ${nextMoney}`)
}

window.onload = async () => {
  questions = JSON.parse(await (await fetch("/questions")).text());
  questions = shuffle(questions);

  setMoneyInfo();
  nextQuestion();
}
